package pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.interactions.Actions;
import org.testng.Assert;

public class Snapdeal {

	WebDriver driver = null;
	Actions actions = new Actions(driver);
	By snalDealSearchbox = By.id("inputValEnter");
	By searchButton = By.cssSelector("span.searchTextSpan");
	By addToCartButton = By.xpath("//*[text()=\"Cart\"]");
	By emptyCartCheck = By.xpath("//h3[text()=\"Shopping Cart is empty!\"]");
	By closeCart = By.cssSelector("span.close-popup-icon");

	public Snapdeal(WebDriver driver) {
		this.driver = driver;
	}

	public void applyFilter(String filter) throws InterruptedException {
		driver.findElement(snalDealSearchbox).isDisplayed();
		driver.findElement(snalDealSearchbox).sendKeys(filter);
		driver.findElement(searchButton).isDisplayed();
		driver.findElement(searchButton).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//*[text()=\"Men's Clothing\"]")).isDisplayed();
		String actual = driver.findElement(By.xpath("//*[text()=\"Men's Clothing\"]")).getText();
		String expected = "Men'S Clothing";
		Assert.assertEquals(actual, expected);
	}

	public void addToCartEmpty() throws InterruptedException {
		driver.findElement(addToCartButton).isDisplayed();
		driver.findElement(addToCartButton).click();
		Thread.sleep(2000);
		driver.findElement(emptyCartCheck).isDisplayed();
		String actual = driver.findElement(emptyCartCheck).getText();
		String expected = "Shopping Cart is empty!";
		Assert.assertEquals(actual, expected);
		driver.findElement(closeCart).isDisplayed();
		driver.findElement(closeCart).click();

	}

}
