import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.*;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import io.github.bonigarcia.wdm.WebDriverManager;
import pages.Snapdeal;

public class TestNGTesting {

	WebDriver driver = null;

	@BeforeTest
	public void setUpTest() {
		WebDriverManager.chromedriver().setup();
		driver = new ChromeDriver();
		// driver.manage().window().maximize();
		driver.get("https://www.snapdeal.com/");
	}

	@Test(priority = 1)
	public void snapdealFilter() throws InterruptedException {
		Snapdeal obj = new Snapdeal(driver);
		obj.applyFilter("Tshirt");

	}

	@Test(priority = 2)
	public void checkVoidCard() throws InterruptedException {
		Snapdeal obj = new Snapdeal(driver);
		obj.addToCartEmpty();
	}

	@AfterTest
	public void tearDown() {
		driver.close();
		driver.quit();
	}
}
